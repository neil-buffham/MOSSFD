Project Name: Breakout_Board
Project Version: #6196385a
Project Url: https://www.flux.ai/spudzilla712/breakoutboard

Project Description:
ESP32 WROOM Dev Module breakout board with attached ULN2003 Stepper driver board to drive 28BYJ-48 5v DC stepper motors. 
- Two layer board
- Based on through-hole components for ease of hand-soldering if needed.
- Designed for ESP32 to be able to control a hall effect sensor, stepper motor, and comms with other modules.
Also has a screw terminal for a hall effect sensor, two 5 pin female JST connectors for side to side power/data/detect pins, screw terminals for up to four of these connections, and an XT30 for power input. Utilizes pin headers to seperate the ESP32 breakout board from most of the custom components for troubleshooting and future multi purpose use-ability.

There are two 5V circuits in the lower half of the board, one of which powers the motor/ULN2003. This way a single jumper pin can be removed to de-power/unplug the motor. I might need to go to three 5v circuits down there though, because I might want to unplug JST power and not affect the Hall Effect Sensor.

A resistor is placed under the ESP32 body because I ran out of space and needed a 10kohm pullup for the hall effect sensor.


